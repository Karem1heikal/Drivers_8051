
#ifndef ADC_PRIVATE_H_
#define ADC_PRIVATE_H_
static void ADC_Delay();

// private func
#define ADC_U32_TIMEOUT 50000;

#define IDLE 0
#define BUSY 1
#endif